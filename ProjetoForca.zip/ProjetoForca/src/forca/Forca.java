package forca;

public class Forca {
	
	public static void exibirForca(int contadorDeErro) {
		switch(contadorDeErro) {
		case 0:
			System.out.println(" ____________");
			System.out.println(" |          |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println("_|_");
			break;
		case 1:
			System.out.println(" ____________");
			System.out.println(" |          |");
			System.out.println(" |          O");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println("_|_");
			break;
		case 2:
			System.out.println(" ____________");
			System.out.println(" |          |");
			System.out.println(" |          O");
			System.out.println(" |          |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println("_|_");
			break;
		case 3:
			System.out.println(" ____________");
			System.out.println(" |          |");
			System.out.println(" |          O");
			System.out.println(" |         /|");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println("_|_");
			break;
		case 4:
			System.out.println(" ____________");
			System.out.println(" |          |");
			System.out.println(" |          O");
			System.out.println(" |         /|\\");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println("_|_");
			break;
		case 5:
			System.out.println(" ____________");
			System.out.println(" |          |");
			System.out.println(" |          O");
			System.out.println(" |         /|\\");
			System.out.println(" |         /");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println("_|_");
			break;
		case 6:
			System.out.println(" ____________");
			System.out.println(" |          |");
			System.out.println(" |          O");
			System.out.println(" |         /|\\");
			System.out.println(" |         / \\");
			System.out.println(" |");
			System.out.println(" |");
			System.out.println("_|_");
			break;
			
		}
	}
	
	public static void exibirPalavra(String palavra, String letrasTentadas) {
	    for (int i = 0; i < palavra.length(); i++) {
	        char letra = palavra.charAt(i);

	    
	        if (letrasTentadas.indexOf(letra) >= 0) {
	            System.out.print(letra + " ");
	        } else {
	            System.out.print("_ ");
	        }
	    }
	    System.out.println();
	}
}