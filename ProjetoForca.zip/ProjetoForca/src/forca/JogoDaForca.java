package forca;

import java.util.Scanner;

public class JogoDaForca {

    private static final String PalavraSecreta = "JAVA";
    private static final String Tema = "PROGRAMAÇÃO";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int tentativasErradas = 0;
        int tentativasMaximas = 6;
        int tentativasFeitas = 0; 
        String letrasTentadas = ""; 
        String palavraSecreta = PalavraSecreta.toLowerCase();

        while (tentativasErradas < tentativasMaximas) {
        	System.out.println("Tema: " + Tema);
            System.out.println("A palavra possui " + palavraSecreta.length() + " letras");
            System.out.println("Erros: " + tentativasErradas + "/" + tentativasMaximas);
            System.out.println("Tentativas feitas: " + tentativasFeitas);
            Forca.exibirForca(tentativasErradas);
            Forca.exibirPalavra(palavraSecreta, letrasTentadas);
            System.out.println("Letras usadas: " + letrasTentadas); 

            System.out.println("Digite uma letra: ");
            String tentativa = scanner.nextLine().toLowerCase(); 

            if (letrasTentadas.indexOf(tentativa) >= 0) {
                System.out.println("Você já tentou essa letra.");
            }

         
            letrasTentadas += tentativa;

           
            if (palavraSecreta.indexOf(tentativa) < 0) {
                tentativasErradas++; 
            }

            tentativasFeitas++;

            boolean ganhou = true;
            for (int i = 0; i < palavraSecreta.length(); i++) {
                if (letrasTentadas.indexOf(palavraSecreta.charAt(i)) < 0) {
                    ganhou = false;
                    break;
                }
            }

            if (ganhou) {
            	System.out.println("Tema: " + Tema);
                System.out.println("A palavra possui " + palavraSecreta.length() + " letras");
            	System.out.println("Erros: " + tentativasErradas + "/" + tentativasMaximas);
        		System.out.println("Tentativas feitas: "+ tentativasFeitas);
        		Forca.exibirForca(tentativasErradas);
        		Forca.exibirPalavra(palavraSecreta, letrasTentadas);
        		System.out.println("Letras usadas: " + letrasTentadas);
                System.out.println("Parabéns! Você acertou a palavra." );
                break;
            }
        }

        	if (tentativasErradas == tentativasMaximas) {
        		System.out.println("Tema: " + Tema);
                System.out.println("A palavra possui " + palavraSecreta.length() + " letras");
        		System.out.println("Erros: " + tentativasErradas + "/" + tentativasMaximas);        		System.out.println("Tentativas feitas: "+ tentativasFeitas);
        		Forca.exibirForca(tentativasErradas);
        		Forca.exibirPalavra(palavraSecreta, letrasTentadas);
        		System.out.println("Letras usadas: " + letrasTentadas);
        		System.out.println("Você perdeu! A palavra era: " + PalavraSecreta);
        }

        scanner.close();
    }
}
